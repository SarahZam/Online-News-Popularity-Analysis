

article_data <- read.csv("C:\\Users\\kruti\\Desktop\\ADS\\Project\\OnlineNewsPopularity\\NewsDataset_final.csv")

article_data<-article_data[!(article_data$n_non_stop_words=="1042"),]

article_data$isPopular <- ifelse(article_data$shares<=median(article_data$shares), "Less Popular","High Popular")

write.csv (article_data, "C:\\Users\\kruti\\Desktop\\ADS\\Project\\OnlineNewsPopularity\\NewsDataset_classification.csv")


-------------------------
mean <- mean(article_data$shares)
mean


median <- median(article_data$shares)
median

quantile <- quantile(article_data$shares)
quantile
