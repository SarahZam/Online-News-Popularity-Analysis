library(RCurl)
library(XML)
library(stringr)

# read csv file
raw_data <- read.table("C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Project\\OnlineNewsPopularity\\OnlineNewsPopularity.csv", sep = ",",header=T, check.names = FALSE, stringsAsFactors = FALSE)

# Data Cleaning by removing unwanted columns
raw_data <- subset(raw_data, select = c(- weekday_is_monday, - weekday_is_tuesday, - weekday_is_wednesday, 
                                        - weekday_is_thursday, - weekday_is_friday, - weekday_is_saturday, 
                                        - weekday_is_sunday, -is_weekend, - LDA_00, - LDA_01, - LDA_02, -  LDA_03,
                                        -  LDA_04))

# Extracting Date from URL field and make it in standard format
raw_data$Date <- strsplit(raw_data$url,"/")
raw_data$Year <- sapply(raw_data$Date, "[[", 4)
raw_data$Month <- sapply(raw_data$Date, "[[", 5)
raw_data$Day <- sapply(raw_data$Date, "[[", 6)
raw_data$Date <- paste(raw_data$Year,raw_data$Month,raw_data$Day,sep="")
raw_data$weekday <- weekdays(as.Date(raw_data$Date,'%Y%m%d'))

# Assign values to each day of week Sunday->0...Saturday->6)
raw_data$weekday <- as.POSIXlt(as.Date(raw_data$Date,'%Y%m%d'))$wday

# Find if day falls in weekend or no
raw_data$isWeekend <- ifelse(raw_data$weekday %in% c(0,6),1,0)

# Handling missing values for Type field to 'Others'
raw_data$Type <- ifelse(raw_data$data_channel_is_bus==1, 1,
                        ifelse(raw_data$data_channel_is_lifestyle==1, 2, 
                               ifelse(raw_data$data_channel_is_entertainment==1, 3, 
                                      ifelse(raw_data$data_channel_is_socmed==1, 4, 
                                             ifelse(raw_data$data_channel_is_tech==1, 5, 
                                                    ifelse(raw_data$data_channel_is_world==1, 6, 7)
                                             )
                                      )
                               )
                        )
)

# Removing unwanted columns
raw_data <- subset(raw_data, select = c(- data_channel_is_lifestyle, - data_channel_is_entertainment, -  data_channel_is_bus, - data_channel_is_socmed, - data_channel_is_tech, - data_channel_is_world))

#raw_data$shares <- log(raw_data$shares)
min(raw_data$shares)
max(raw_data$shares)

# Write dataset to csv file
write.csv (raw_data, "C:\\Users\\Ankur\\Desktop\\ADS\\ADS_Assignments\\Project\\OnlineNewsPopularity\\ModelingDataset_final.csv")


lm_fit <- lm(raw_data$shares ~ .,data = raw_data)
