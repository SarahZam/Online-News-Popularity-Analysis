library(RCurl)
library(XML)
library(stringr)

# read csv file
raw_data <- read.table("C:\\Users\\user\\Downloads\\ADS\\Final Project\\Dataset\\OnlineNewsPopularity\\
                       OnlineNewsPopularity\\OnlineNewsPopularity.csv", sep = ",",header=T, check.names = FALSE, stringsAsFactors = FALSE)

# Data Cleaning by removing unwanted columns
raw_data <- subset(raw_data, select = c(-n_unique_tokens, - n_non_stop_words, 
                                        - n_non_stop_unique_tokens, - kw_min_min,- kw_max_min,
                                        - kw_avg_min, - kw_min_max,- kw_max_max,- kw_avg_max,
                                        - kw_min_avg,- kw_max_avg, - kw_avg_avg, - weekday_is_monday,
                                        - weekday_is_tuesday,- weekday_is_wednesday, - weekday_is_thursday,
                                        - weekday_is_friday, - weekday_is_saturday, - weekday_is_sunday,
                                        - is_weekend, - LDA_00, - LDA_01, - LDA_02, -  LDA_03,
                                        -  LDA_04))

# Extracting Date from URL field and make it in standard format
raw_data$Date <- strsplit(raw_data$url,"/")
raw_data$Year <- sapply(raw_data$Date, "[[", 4)
raw_data$Month <- sapply(raw_data$Date, "[[", 5)
raw_data$Day <- sapply(raw_data$Date, "[[", 6)
raw_data$Date <- paste(raw_data$Year,raw_data$Month,raw_data$Day,sep="")
raw_data$weekday <- weekdays(as.Date(raw_data$Date,'%Y%m%d'))

# Assign values to each day of week Sunday->0...Saturday->6)
raw_data$weekday <- as.POSIXlt(as.Date(raw_data$Date,'%Y%m%d'))$wday

# Find if day falls in weekend or no
raw_data$isWeekend <- ifelse(raw_data$weekday %in% c(0,6),1,0)

# Handling missing values for Type field to 'Others'
raw_data$Type <- ifelse(raw_data$data_channel_is_bus==1, 1,
                        ifelse(raw_data$data_channel_is_lifestyle==1, 2, 
                               ifelse(raw_data$data_channel_is_entertainment==1, 3, 
                                      ifelse(raw_data$data_channel_is_socmed==1, 4, 
                                             ifelse(raw_data$data_channel_is_tech==1, 5, 
                                                    ifelse(raw_data$data_channel_is_world==1, 6, 7))))))

# Removing unwanted columns
raw_data <- subset(raw_data, select = c(- data_channel_is_lifestyle, - data_channel_is_entertainment, -  data_channel_is_bus, - data_channel_is_socmed, - data_channel_is_tech, - data_channel_is_world))

raw_data$shares1 <- log(raw_data$shares)
hist(raw_data$shares1)
# Write dataset to csv file
write.csv (raw_data, "C:\\Users\\user\\Downloads\\ADS\\Final Project\\Dataset\\NewsDataset_final.csv")

ds <- read.csv("C:\\Users\\user\\Downloads\\ADS\\Final Project\\Dataset\\NewsDataset_final.csv", stringsAsFactors = FALSE)

siteData <- function(N) {
  html<-getURL(N)
  doc = htmlParse(html, asText = TRUE)
  scraped<-c(url=N, type=xpathSApply(doc, "//*[@id='main']/div[1]/div/hgroup/h2", xmlValue))
  scraped<-c(scraped, topic=xpathSApply(doc, "//*[@id='main']/div[1]/div/div/div/div[2]/div/article/footer", xmlValue))
  scraped<-c(scraped, author=xpathSApply(doc, "//*[@id='main']/div[1]/div/div/div/div[2]/div/article/header/div[2]/span/span/a", xmlValue))
}
scrapedDf0<-lapply(ds[1:4000,2], siteData)
workWithScraped0<-scrapedDf0
res <- as.data.frame(t(stri_list2matrix(workWithScraped0)))
res<-res[,-5]
colnames(res) <- c("url", "tpye", "topics", "author")
res[,"topics"]<-gsub("\n","",res$topics)
res[,"topics"]<-gsub("Topics:","",res$topics)
res[,"topics"]<-trimws(res$topics)

scrapedDataSet<-merge(ds, res, by = "url")
scrapedDataSet<-scrapedDataSet[,-2]
scrapedDataSet1<-na.omit(scrapedDataSet)
write.csv (scrapedDataSet, "C:\\Users\\user\\Downloads\\ADS\\Final Project\\Dataset\\NewsDataset_final2.csv")