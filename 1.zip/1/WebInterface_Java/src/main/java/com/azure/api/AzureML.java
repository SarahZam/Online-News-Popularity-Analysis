package com.azure.api;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Iterator;
import java.util.zip.InflaterInputStream;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class AzureML {
	   
	    public static String apiurl;
	    public static String apikey;
	    
	    // Regression
	    // Calling random Forest model
	    public String callDecisionForestService(String json) {
	    	System.out.println("calling random forest model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/fe3634327aff44fbbf5e492016b4f4f4/services/b5807a967d9f4145a26e0d7d7690ccaf/execute?api-version=2.0&details=true";
	    	apikey = "Wpnk2YRAp9ag5CfHyb2k3AU5heCLDy3OLvUa55S2q3QzTrZTBnTHFvA4eCE9ro2rlY+OosoRIUqzJAiAibYYWA==";
	    		    	
	    	String result = rrsHttpPost(json);
	    	return retrieveOutput(result, "Regression", 1);
	    }
	    
	    // Calling Neural network model
	    public String callNeuralNetworkService(String json) {
	    	System.out.println("calling neural network model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/fe3634327aff44fbbf5e492016b4f4f4/services/7154e64ebf1745389d8b54efe1afa2e1/execute?api-version=2.0&details=true";
	    	apikey = "e/Xrs8SddOOsdibtwAlLmihsfFclt09RclA+VRIzh4qBIVNXdR7TA1wLRIkQClofTP8F0qcjrlxmOE+6Yh9J1w==";
	    	
	    	String input = rrsHttpPost(json);
	    	return retrieveOutput(input, "Regression", 2);
	    }
	    
	    // Calling Linear Regression model 
	    public String callPoissonRegressionService(String json) {
	    	System.out.println("calling linear regression model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/fe3634327aff44fbbf5e492016b4f4f4/services/d69f8872d8e04e19914dc375b84dda6f/execute?api-version=2.0&details=true";
	    	apikey = "KUkxdzXFgWQvQqMntV7Pqr3SF7AO68GzjQ53sJZoBX4qF1xteKWXhISgrABolO6RNLfjgzg6EPEFT97UhkpKUA==";
	    	
	    	String input = rrsHttpPost(json);
	    	return retrieveOutput(input, "Regression", 3);	
	    }
	    
	    // Calling Boosted Decision Tree model 
	    public String callBoostedDecisionTreeService(String json) {
	    	System.out.println("calling boosted decision tree regression model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/fe3634327aff44fbbf5e492016b4f4f4/services/4140765d3ea8460ca9c691c37f8e4078/execute?api-version=2.0&details=true";
	    	apikey = "kf1D1V0TYFkKto7aJVkgKRVm3owztnQY8b5rLbqJSnhqR33r6LZXd8Qoy/ImfdFfIS8LNpEyeit0ooqJG5fP4w==";
	    	
	    	String input = rrsHttpPost(json);
	    	return retrieveOutput(input, "Regression", 4);	
	    }
	    
	    //Classification
	    // Calling Logistic Classification
	    public String callLogisticClassificationService(String json) {
	    	System.out.println("calling logistic classification model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/1893663180d44b459c8fe63a23a70448/services/f70ada5de8a64995828f5c801f4f6d78/execute?api-version=2.0&details=true";
	    	apikey = "hFMZOXffrlk9Qr+9Mvy81IcQIhI1t2qqnpSSj1aaDQW00YAoTmu0ZCGlhywuUt7iFBR2c+X2CRpxIqv4tpt58A==";
	    	
	    	String input = rrsHttpPost(json);
	    	return retrieveOutput(input, "Classification", 5);	
	    }
	    
	    // Calling Neural Classification
	    public String callNeuralClassificationService(String json) {
	    	System.out.println("calling neural classification model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/fe3634327aff44fbbf5e492016b4f4f4/services/3e1fddbe0dd447b1883720cda9a5115f/execute?api-version=2.0&details=true";
	    	apikey = "NhMNNJSSthOcRg8sr4nE7YwvSXjO/9PEnKt8JE+4agYj9/mCIJbc0PIcbhggwZxZtU671p/T64o7F+DR8yXlyQ==";
	    	
	    	String input = rrsHttpPost(json);
	    	return retrieveOutput(input, "Classification", 6);	
	    }
	    
	    // Calling Decision Tree Classification
	    public String callDecisionTreeClassificationService(String json) {
	    	System.out.println("calling decision tree classification model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/fe3634327aff44fbbf5e492016b4f4f4/services/258e3e3b2c6b4cbb9d2d16675610ffe3/execute?api-version=2.0&details=true";
	    	apikey = "T6G5vd8bU7osf9PILxQhtI6ryLBF/V0kd0qkpzDpC2lmjrBiBkzHd8O5OHN02xfWAiKYVSUhM5GFgbkPSgKSAw==";
	    	
	    	String input = rrsHttpPost(json);
	    	return retrieveOutput(input, "Classification", 7);	
	    }
	    
	    // Calling Random Forest Classification
	    public String callRandomForestClassificationService(String json) {
	    	System.out.println("calling decision forest classification model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/fe3634327aff44fbbf5e492016b4f4f4/services/1ba7d1c88eb641e1bb8e6979eb0a2f35/execute?api-version=2.0&details=true";
	    	apikey = "PFTWGC0NPvofAZnYyilvQCRG0jtPAAsRC1G0koR3euhCL7CflaPj7Wl2qoChYmUX7gAdcDHYBm2e7CfKjCQ2sg==";
	    	
	    	String input = rrsHttpPost(json);
	    	return retrieveOutput(input, "Classification", 8);	
	    }
	    
	    // Clustering
	    // Calling K-Means Clustering
	    public String callKMeansClusteringService(String json) {
	    	System.out.println("calling K-Means Clustering model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/fe3634327aff44fbbf5e492016b4f4f4/services/4f23e2d4148949e0b1a5d1ec2ca56661/execute?api-version=2.0&details=true";
	    	apikey = "vQtu40LUwYDkunHSUTpy/950GgIvvVrii2gnJveG+GrVS8HurcymVuu3/2uUaDgJGZ8wT1DtfpNYRn7x0i8Tbg==";
	    	
	    	String input = rrsHttpPost(json);
	    	return retrieveOutput(input, "Clustering", 9);	
	    }
	    
	    // Calling Hierarchical Clustering
	    public String callHierarchicalClusteringService(String json) {
	    	System.out.println("calling K-Means Clustering model: ");
	    	
	    	apiurl = "https://ussouthcentral.services.azureml.net/workspaces/fe3634327aff44fbbf5e492016b4f4f4/services/429d98d8983d4565b8c1a118c9dc09b5/execute?api-version=2.0&details=true";
	    	apikey = "OqlyenMhBLPh0Zoei+35PFIbyvbhwT4AEWE4O+QCubb+jk2HrvBkQdblBZVyJDTlVVM3DvmzO6WKAKN0aTeSuQ==";
	    	
	    	String input = rrsHttpPost(json);
	    	return retrieveOutput(input, "Clustering", 10);	
	    }
	   
	    /**
	     * Call REST API for retrieving prediction from Azure ML 
	     * @return response from the REST API
	     */	
	    public String rrsHttpPost(String jsonBody) {
	        
	        HttpPost post;
	        HttpClient client;
	        StringEntity entity;
	        
	        try {
	        	
	            // create HttpPost and HttpClient object
	            post = new HttpPost(apiurl);
	            client = HttpClientBuilder.create().build();
	            
	            // setup output message by copying JSON body into 
	            // apache StringEntity object along with content type
	            entity = new StringEntity(jsonBody, HTTP.UTF_8);
	            entity.setContentEncoding(HTTP.UTF_8);
	            entity.setContentType("text/json");

	            // add HTTP headers
	            post.setHeader("Accept", "text/json");
	            post.setHeader("Accept-Charset", "UTF-8");
	        
	            // set Authorization header based on the API key
	            post.setHeader("Authorization", ("Bearer "+apikey));
	            post.setEntity(entity);

	            // Call REST API and retrieve response content
	            HttpResponse authResponse = client.execute(post);
	            
	            return EntityUtils.toString(authResponse.getEntity());
	            
	        }
	        catch (Exception e) {   
	            System.out.println("Error occurred while calling the service!!");
	            return e.toString();
	        }
	    }	 
	    
	    public String retrieveOutput(String input, String modelType, int num) {
			
	    	try {
		    	JSONParser parser = new JSONParser();	    	
		    	Object obj = parser.parse(input);	 
		    	
				JSONObject json = (JSONObject) obj;
								
			   JSONObject result = (JSONObject) json.get("Results");
			   System.out.println(json.get("Results"));
				
		       JSONObject output1 = (JSONObject)result.get("output1");
		       System.out.println(result.get("output1"));	
		       
		       JSONObject value = (JSONObject)output1.get("value");
		       System.out.println(output1.get("value"));
		        
		       String res = null; 
		       JSONArray strArray = (JSONArray)value.get("Values");				
		       Iterator<Object> itr = strArray.iterator();
			
				
				while(itr.hasNext()) {
					res = itr.next().toString();
					break;
				}
				
				StringBuilder sb = new StringBuilder();
				sb.append(res);
				
				if(modelType.equalsIgnoreCase("Regression")) {
					String op[] = res.split(",");
					String inter = (op[9]).substring(1, 9);
					Double doub = Double.parseDouble(inter);
					Double calc = (doub*(843300-1))+1;
					int pred = calc.intValue();
					String result_first = "The Predicted number of shares by ";
					if (num==1) {
						String output = result_first + "Random Forest Regression is " + pred;
						return output;
					} else if (num==2) {
						String output = result_first + "Neural Network Regression is " + pred;
						return output;
					} else if (num==3) {
						String output = result_first + "Poisson Regression Regression is " + pred;
						return output;
					} else if (num==4) {
						String output = result_first + "Boosted Decision Regression is " + pred;
						return output;
					}
				} else if(modelType.equalsIgnoreCase("Classification")) {
					String op[] = res.split(",");
					String result_first = "The article to be published is classified as ";
					if (num==6) {
						String output = result_first + op[10] + " according to Neural Network Classification" ;
						return output;
					} else if (num==7) {
						String output = result_first + op[10] + " according to Decision Tree Classification";
						return output;
					} else if (num==8) {
						String output = result_first + op[10] + " according to Random Forest Classification" ;
						return output;
					}
				} else if(modelType.equalsIgnoreCase("Clustering")) {
					String op[] = res.split(",");
					String result_first = "Cluster Number is ";
					if (num==9) {
						String output = result_first + op[10];
						return output;
					} 
					if (num==10) {
						String output = result_first + op[10];
						return output;
					}
				}
				
				
				//String op[] = res.split(",");
				//String s = res.substring(2,sb.indexOf("]"));				
				
				//String output =	s.substring(0,s.lastIndexOf('"'));
				String output = res;
				System.out.println(output);
				return output;
	    	}
	    	catch(Exception e) {
	    		System.out.println("Error while parsing output!!");
	    		e.printStackTrace();;
	    	}
	    	
	    	return null;
	    }
	    }