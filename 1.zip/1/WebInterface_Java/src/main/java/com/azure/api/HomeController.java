package com.azure.api;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	public static String jsonBody;

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	/**
	 * Simply selects the home view to render by returning its name.
	 */

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "index";
	}

	@RequestMapping(value = "/service", method = RequestMethod.POST)
	public ModelAndView service(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");

		String analyticsType = request.getParameter("analyticsType");

		// Regression
		if (analyticsType.equals("regression")) {

			String date = request.getParameter("date");
			String newsType = request.getParameter("newstype");
			String isWeekend = request.getParameter("isWeekend");
			String nTokensTitle = request.getParameter("nTokensTitle");
			String nTokensContent = request.getParameter("nTokensContent");
			String numhrefs = request.getParameter("numhrefs");
			String numimages = request.getParameter("numimages");
			String numvideos = request.getParameter("numvideos");
			String numkeywords = request.getParameter("numkeywords");
			String model = request.getParameter("model");

			int weekday = -1;
			int month = -1;
			int day = -1;
			String jsonBody = null;

			if (date == "" || numkeywords == "" || isWeekend == "" || nTokensTitle == "" || nTokensContent == "" || numhrefs == ""
					|| numimages == "" || numvideos == "" || numkeywords == "" ) {
				mv.addObject("error", "no_value");
				return mv;
			}

			int weekend = Integer.parseInt(isWeekend);
			System.out.println(weekend);

			if (weekend<0 || weekend>1) {
				mv.addObject("error", "weekend");
				return mv;
			}

			int type = Integer.parseInt(newsType);
			if (type < 0 || type > 7) {
				mv.addObject("error", "type");
				return mv;
			}

			int tokentitle = Integer.parseInt(nTokensTitle);
			int tokencontent = Integer.parseInt(nTokensContent);
			int links = Integer.parseInt(numhrefs);
			int images = Integer.parseInt(numimages);
			int vidoes = Integer.parseInt(numvideos);
			int keywords = Integer.parseInt(numkeywords);

			try {
				DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
				Date startDate = (Date) formatter.parse(date);
				day = Integer.parseInt(date.replaceAll("-", ""));
				Calendar cal = Calendar.getInstance();
				cal.setTime(startDate);
				month = cal.get(Calendar.MONTH) + 1;
				// day = cal.get(Calendar.DAY_OF_MONTH);

				/* creating json from form values */

				JSONObject obj = new JSONObject();
				JSONObject inputs = new JSONObject();
				JSONObject input = new JSONObject();

				JSONArray columnName = new JSONArray();
				
				columnName.add("n_tokens_title");
				columnName.add("n_tokens_content");
				columnName.add("num_hrefs");
				columnName.add("num_imgs");
				columnName.add("num_videos");
				columnName.add("num_keywords");
				columnName.add("Date");
		        columnName.add("isWeekend");
				columnName.add("Type");
				

				JSONArray allValues = new JSONArray();
				JSONArray value = new JSONArray();
				
				value.add(tokentitle);
				value.add(tokencontent);
				value.add(links);
				value.add(images);
				value.add(vidoes);
				value.add(keywords);
				value.add(day);
				value.add(weekend);
				value.add(type);
				
				allValues.add(value);

				input.put("ColumnNames", columnName);
				input.put("Values", allValues);
				inputs.put("input1", input);
				obj.put("Inputs", inputs);

				System.out.println("print the value of json " + obj);

				// converting json to string
				jsonBody = obj.toString();
			} catch (Exception e) {
				System.out.println("Error occurred!!" + e);
			}

			// Creating instance of azure class
			AzureML am = new AzureML();

			String res = null;
			System.out.println("Model: " + model);

			if (model.equals("forest")) {
				res = am.callDecisionForestService(jsonBody);
			} else if (model.equals("neural")) {
				res = am.callNeuralNetworkService(jsonBody);
			} else if (model.equals("poisson")) {
				res = am.callPoissonRegressionService(jsonBody);
			} else if (model.equals("decision")) {
				res = am.callBoostedDecisionTreeService(jsonBody);
			}

			if (res != null) {
				System.out.println("Result of web service :" + res);

				mv.addObject("output", res);
			} else {
				System.out.println("Error thrown by web service call!!");
				mv.addObject("error", "invalid");
				return mv;
			}
			
		} 
//-----------------------------------------------------------------------------------
		// Classification
		else if (analyticsType.equals("classification")) {
			System.out.println("In Classification");

			String newsType = request.getParameter("newstype");
			String isWeekend = request.getParameter("isWeekend");
			String weekday = request.getParameter("weekday");
			String nTokensTitle = request.getParameter("nTokensTitle");
			String nTokensContent = request.getParameter("nTokensContent");
			String nNonStopWords = request.getParameter("nNonStopWords");
			String numhrefs = request.getParameter("numhrefs");
			String numselfhrefs = request.getParameter("numselfhrefs");
			String numimages = request.getParameter("numimages");
			String numkeywords = request.getParameter("numkeywords");
			String model = request.getParameter("modelc");

			String jsonBody = null;
			
			if (weekday == "" || numkeywords == "" || isWeekend == "" || nTokensTitle == "" || nTokensContent == "" || numhrefs == ""
					|| numimages == "" || numselfhrefs == "" || numkeywords == "" || nNonStopWords =="") {
				mv.addObject("error", "no_value");
				return mv;
			}
			
			int weekend = Integer.parseInt(isWeekend);
			System.out.println(weekend);

			if (weekend<0 || weekend>1) {
				mv.addObject("error", "weekend");
				return mv;
			}

			int type = Integer.parseInt(newsType);
			if (type < 0 || type > 7) {
				mv.addObject("error", "type");
				return mv;
			}
			
			int weekofday = Integer.parseInt(weekday);
			if (weekofday < 0 || weekofday > 7) {
				mv.addObject("error", "week");
				return mv;
			}

			int tokentitle = Integer.parseInt(nTokensTitle);
			int tokencontent = Integer.parseInt(nTokensContent);
			int nonstopwords = Integer.parseInt(nNonStopWords);
			int links = Integer.parseInt(numhrefs);
			int selflinks = Integer.parseInt(numselfhrefs);
			int images = Integer.parseInt(numimages);
			int keywords = Integer.parseInt(numkeywords);
			
			try {
				/* creating json from form values */

				JSONObject obj = new JSONObject();
				JSONObject inputs = new JSONObject();
				JSONObject input = new JSONObject();

				JSONArray columnName = new JSONArray();
				
				columnName.add("n_tokens_title");
				columnName.add("n_tokens_content");
				columnName.add("n_non_stop_words");
				columnName.add("num_hrefs");
				columnName.add("num_self_hrefs");
				columnName.add("num_imgs");
				columnName.add("num_keywords");
				columnName.add("weekday");
		        columnName.add("isWeekend");
				columnName.add("Type");

				JSONArray allValues = new JSONArray();
				JSONArray value = new JSONArray();
				value.add(tokentitle);
				value.add(tokencontent);
				value.add(nonstopwords);
				value.add(links);
				value.add(selflinks);
				value.add(images);
				value.add(keywords);
				value.add(weekofday);
				value.add(weekend);
				value.add(type);

				allValues.add(value);

				input.put("ColumnNames", columnName);
				input.put("Values", allValues);
				inputs.put("input1", input);
				obj.put("Inputs", inputs);

				System.out.println("print the value of json " + obj);

				// converting json to string
				jsonBody = obj.toString();
			} catch (Exception e) {
				System.out.println("Error occurred!!" + e);
			}
			// Creating instance of azure class
			AzureML am = new AzureML();

			String res = null;
			System.out.println("Model: " + model);

			if (model.equals("treec")) {
				res = am.callDecisionTreeClassificationService(jsonBody);
			} else if (model.equals("forestc")) {
				res = am.callRandomForestClassificationService(jsonBody);
			} else if (model.equals("neuralc")) {
				res = am.callNeuralClassificationService(jsonBody);
			}

			if (res != null) {
				System.out.println("Result of web service :" + res);

				mv.addObject("output", res);
			} else {
				System.out.println("Error thrown by web service call!!");
				mv.addObject("error", "invalid");
				return mv;
			}
		} 
//-------------------------------------------------------------------------------------		
		// Clustering
		else if (analyticsType.equals("cluster")) {
			System.out.println("In Clustering");

			String date = request.getParameter("date");
			String newsType = request.getParameter("newstype");
			String nTokensTitle = request.getParameter("nTokensTitle");
			String nTokensContent = request.getParameter("nTokensContent");
			String numhrefs = request.getParameter("numhrefs");
			String numselfhrefs = request.getParameter("numselfhrefs");
			String numimages = request.getParameter("numimages");
			String numkeywords = request.getParameter("numkeywords");
			String numshares = request.getParameter("numshares");
			String model = request.getParameter("model_cluster");
			String url = request.getParameter("url");

			int weekday = -1;
			int month = -1;
			int day = -1;
			String jsonBody = null;

			if (date == "" || numselfhrefs == "" || numshares == "" || nTokensTitle == "" || nTokensContent == "" || numhrefs == ""
					|| numimages == "" || newsType == "" || numkeywords == "" || url =="") {
				mv.addObject("error", "no_value");
				return mv;
			}
			
			int type = Integer.parseInt(newsType);
			if (type < 0 || type > 7) {
				mv.addObject("error", "type");
				return mv;
			}
			
			int tokentitle = Integer.parseInt(nTokensTitle);
			int tokencontent = Integer.parseInt(nTokensContent);
			int links = Integer.parseInt(numhrefs);
			int selflinks = Integer.parseInt(numselfhrefs);
			int images = Integer.parseInt(numimages);
			int keywords = Integer.parseInt(numkeywords);
			int shares = Integer.parseInt(numshares);
			
			try {
				
				DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
				Date startDate = (Date) formatter.parse(date);
				day = Integer.parseInt(date.replaceAll("-", ""));
				Calendar cal = Calendar.getInstance();
				cal.setTime(startDate);
				month = cal.get(Calendar.MONTH) + 1;
				
				/* creating json from form values */

				JSONObject obj = new JSONObject();
				JSONObject inputs = new JSONObject();
				JSONObject input = new JSONObject();

				JSONArray columnName = new JSONArray();
				
				columnName.add("url");
				columnName.add("n_tokens_title");
				columnName.add("n_tokens_content");
				columnName.add("num_hrefs");
				columnName.add("num_self_hrefs");
				columnName.add("num_imgs");
				columnName.add("num_keywords");
				columnName.add("shares");
		        columnName.add("Date");
				columnName.add("Type");

				JSONArray allValues = new JSONArray();
				JSONArray value = new JSONArray();
				
				value.add(url);
				value.add(tokentitle);
				value.add(tokencontent);
				value.add(links);
				value.add(selflinks);
				value.add(images);
				value.add(keywords);
				value.add(shares);
				value.add(day);
				value.add(type);

				allValues.add(value);

				input.put("ColumnNames", columnName);
				input.put("Values", allValues);
				inputs.put("input1", input);
				obj.put("Inputs", inputs);

				System.out.println("print the value of json " + obj);

				// converting json to string
				jsonBody = obj.toString();
			} catch (Exception e) {
				System.out.println("Error occurred!!" + e);
			}
			// Creating instance of azure class
			AzureML am = new AzureML();

			String res = null;
			System.out.println("Model: " + model);

			if (model.equals("kmeans")) {
				res = am.callKMeansClusteringService(jsonBody);
			} else if (model.equals("hie")) {
				res = am.callHierarchicalClusteringService(jsonBody);
			} 

			if (res != null) {
				System.out.println("Result of web service :" + res);

				mv.addObject("output", res);
			} else {
				System.out.println("Error thrown by web service call!!");
				mv.addObject("error", "invalid");
				return mv;
			}
		}

		return mv;
	}

}
